--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.1
-- Dumped by pg_dump version 11.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE posjava;
--
-- Name: posjava; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE posjava WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Portuguese_Brazil.1252' LC_CTYPE = 'Portuguese_Brazil.1252';


ALTER DATABASE posjava OWNER TO postgres;

\connect posjava

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: user_telefone_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_telefone_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_telefone_sequence OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: telefoneuser; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.telefoneuser (
    id bigint DEFAULT nextval('public.user_telefone_sequence'::regclass) NOT NULL,
    numero character varying(255) NOT NULL,
    tipo character varying(255) NOT NULL,
    usuariopessoa bigint NOT NULL
);


ALTER TABLE public.telefoneuser OWNER TO postgres;

--
-- Name: user_sequence; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_sequence
    START WITH 7
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 9999999
    CACHE 1;


ALTER TABLE public.user_sequence OWNER TO postgres;

--
-- Name: userposjava; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.userposjava (
    id bigint DEFAULT nextval('public.user_sequence'::regclass) NOT NULL,
    nome character varying(255),
    email character varying(255)
);


ALTER TABLE public.userposjava OWNER TO postgres;

--
-- Name: telefoneuser telefone_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telefoneuser
    ADD CONSTRAINT telefone_id PRIMARY KEY (id);


--
-- Name: userposjava user_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userposjava
    ADD CONSTRAINT user_pk PRIMARY KEY (id);


--
-- Name: userposjava userposjava_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userposjava
    ADD CONSTRAINT userposjava_id_key UNIQUE (id);


--
-- Name: userposjava userposjava_id_key1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.userposjava
    ADD CONSTRAINT userposjava_id_key1 UNIQUE (id);


--
-- Name: telefoneuser telefoneuser_usuariopessoa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telefoneuser
    ADD CONSTRAINT telefoneuser_usuariopessoa_fkey FOREIGN KEY (usuariopessoa) REFERENCES public.userposjava(id);


--
-- PostgreSQL database dump complete
--

